SELECT "IdTipoProducto", "IdCategoriaProducto", "Nombre", "Activo", "Actualiza"
FROM "TipoProducto"
WHERE "Activo" = b'1';
