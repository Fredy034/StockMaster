SELECT "IdPais", "Nombre", "Activo", "Actualiza"
FROM "Pais"
WHERE "Activo" = '1'