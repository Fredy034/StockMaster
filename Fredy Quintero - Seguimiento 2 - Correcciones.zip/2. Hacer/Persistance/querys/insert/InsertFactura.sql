INSERT INTO "Factura" ("IdEstadoFactura", "IdMetodoPago", "IdEmpleado", "IdCliente", "NumeroFactura", "Fecha", "Total", "Notas")
VALUES ('id-estado-factura', 'id-metodo-pago', 'id-empleado', 'id-cliente', 'Número de Factura', '2024-09-01 12:00:00', 1000.00, 'Notas de la Factura');
