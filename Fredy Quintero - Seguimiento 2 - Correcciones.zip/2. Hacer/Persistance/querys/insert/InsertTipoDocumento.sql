INSERT INTO "TipoDocumento" ("Nombre")
VALUES ('Nombre del Tipo de Documento');
