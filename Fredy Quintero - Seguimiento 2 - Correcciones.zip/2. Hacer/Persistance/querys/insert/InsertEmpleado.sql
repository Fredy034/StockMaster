INSERT INTO "Empleado" ("IdPersona", "IdSucursal", "FechaContratacion", "Salario")
VALUES ('id-persona', 'id-sucursal', '2024-09-01', 50000.00);
