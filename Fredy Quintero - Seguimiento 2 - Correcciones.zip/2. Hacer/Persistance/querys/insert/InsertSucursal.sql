INSERT INTO "Sucursal" ("IdCiudad", "IdTienda", "Nombre")
VALUES ('id-ciudad', 'id-tienda', 'Nombre de la Sucursal');
