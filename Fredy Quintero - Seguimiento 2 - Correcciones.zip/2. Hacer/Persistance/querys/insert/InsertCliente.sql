INSERT INTO "Cliente" ("IdPersona", "FechaRegistro", "Direccion")
VALUES ('id-persona', '2024-09-01', 'Dirección del Cliente');
