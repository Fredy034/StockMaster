INSERT INTO "CategoriaProducto" ("Nombre", "Descripcion")
VALUES ('Nombre de la Categoría', 'Descripción de la Categoría');
