CREATE TABLE "Pais" (
	"IdPais" UUID NOT NULL UNIQUE DEFAULT uuid_generate_v4(),
	"Nombre" VARCHAR(255) NOT NULL,
	"Activo" BIT NOT NULL DEFAULT b'1',
	"Actualiza" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY("IdPais")
);

COMMENT ON COLUMN "Pais"."IdPais" IS '';
COMMENT ON COLUMN "Pais"."Nombre" IS '';
COMMENT ON COLUMN "Pais"."Activo" IS '';
COMMENT ON COLUMN "Pais"."Actualiza" IS '';