INSERT INTO "TipoProducto" ("IdCategoriaProducto", "Nombre")
VALUES 
('62e89e62-c8c8-4dbb-b03b-c8713d4d6465', 'Arroz'),
('62e89e62-c8c8-4dbb-b03b-c8713d4d6465', 'Aceite'),
('5e11ba5b-1196-4e97-bd0d-14a68fa75045', 'Leche'),
('6ef359f6-76ee-45e8-9098-f40c2c9f124f', 'Pan de Molde');
