INSERT INTO "Ciudad" ("IdDepartamento", "Nombre")
VALUES 
('08387c74-e08c-4ee5-a0d9-d943561febda', 'Medellín'),
('2761fe4b-616a-478f-88c6-c5f67d07d8c9', 'Bogotá'),
('3e84935d-324d-4c3b-bee5-6ca6df1a4f13', 'Cali');
