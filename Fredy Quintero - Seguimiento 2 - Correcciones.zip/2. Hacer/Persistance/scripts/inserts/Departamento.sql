INSERT INTO "Departamento" ("IdPais", "Nombre")
VALUES 
('9ecae1dd-3414-429c-96c5-1a70d14f122d', 'Antioquia'),
('9ecae1dd-3414-429c-96c5-1a70d14f122d', 'Cundinamarca'),
('9ecae1dd-3414-429c-96c5-1a70d14f122d', 'Valle del Cauca');
