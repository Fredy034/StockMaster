INSERT INTO "MetodoPago" ("Nombre", "Descripcion")
VALUES 
('Tarjeta de Crédito', 'Pago mediante tarjeta de crédito'),
('Efectivo', 'Pago en efectivo'),
('Transferencia Bancaria', 'Transferencia desde cuenta bancaria');
