INSERT INTO "TipoDocumento" ("Nombre")
VALUES 
('Cédula de Ciudadanía'),
('Pasaporte'),
('Tarjeta de Identidad');
