const express = require('express');
const router = express.Router();

const { ModelProductoEntity, modelproductoentity } = require('../../../domain/entitie/producto/modelProductoEntity');

// GET all products
/**
 * @swagger
 * /getproductentity:
 *  get:
 *    summary: Get Producto
 *    tags: [Producto]
 *    responses:
 *      200:
 *        description: Get all productos
 */

router.get('/getproductentity', (req, res) => {
  // res.json(modelproductoentity);
  res.status(200).json(['Esto', 'Es', 'Una', 'Prueba', 'De', 'Producto']);
});

// POST a new product
/**
 * @swagger
 * /addproductentity:
 *  post:
 *    summary: Add a new Producto
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            $ref: '#/components/schemas/ModelProductoEntity'
 *    tags: [Producto]
 *    responses:
 *      201:
 *        description: Producto added
 *      400:
 *        description: Bad request, missing required fields
 */

/*
PAYLOAD EXAMPLE:
{
    "idproducto": "1",
    "idtipoproducto": "1",
    "nombre": "1",
    "descripcion": "1",
    "precio": "1",
    "stock": "1"
    "activo": "1",
    "actualiza": "1"
}
*/

router.post('/addproductentity', (req, res) => {
  const { idproducto, idtipoproducto, nombre, descripcion, precio, stock, activo, actualiza } = req.body;

  if (!idproducto || !idtipoproducto || !nombre || !descripcion || !precio || !stock || !activo || !actualiza) {
    return res.status(400).json({ msg: 'Faltan campos por llenar, completa los campos requeridos' });
  }

  const newModelProductoEntity = new ModelProductoEntity(
    idproducto,
    idtipoproducto,
    nombre,
    descripcion,
    precio,
    stock,
    activo,
    actualiza
  );

  modelproductoentity.push(newModelProductoEntity);
  res.status(201).json({ msg: 'Producto agregado', product: newModelProductoEntity });
  // res.json(newModelProductoEntity);
});

module.exports = router;
