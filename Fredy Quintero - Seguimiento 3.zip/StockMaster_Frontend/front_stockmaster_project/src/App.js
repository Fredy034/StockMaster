import React from 'react';
import './App.css';
import ProductCard from './ProductCard';
import ProductSearch from './ProductSearch';

function App() {
  return (
    <div className='App'>
      <main className='main'>
        <h2>Consulta de Productos</h2>
        <section className='products-container'>
          <div className='inner-container'>
            <p>Consulta de productos específicos</p>
            {/* nombre, id */}
            <ProductSearch />
          </div>
          <div className='inner-container'>
            <p>Consulta de todos los productos</p>
            <ProductCard />
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;
