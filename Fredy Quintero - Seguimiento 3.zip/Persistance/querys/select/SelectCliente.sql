SELECT "IdCliente", "IdPersona", "FechaRegistro", "Direccion", "Activo", "Actualiza"
FROM "Cliente"
WHERE "Activo" = b'1';
