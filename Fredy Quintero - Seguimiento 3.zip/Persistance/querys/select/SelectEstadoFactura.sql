SELECT "IdEstadoFactura", "Nombre", "Descripcion", "Activo", "Actualiza"
FROM "EstadoFactura"
WHERE "Activo" = b'1';
