SELECT "IdSucursal", "IdCiudad", "IdTienda", "Nombre", "Activo", "Actualiza"
FROM "Sucursal"
WHERE "Activo" = b'1';
