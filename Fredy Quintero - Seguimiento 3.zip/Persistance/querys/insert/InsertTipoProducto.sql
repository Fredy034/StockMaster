INSERT INTO "TipoProducto" ("IdCategoriaProducto", "Nombre")
VALUES ('id-categoria-producto', 'Nombre del Tipo de Producto');
