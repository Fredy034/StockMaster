INSERT INTO "EstadoFactura" ("Nombre", "Descripcion")
VALUES ('Nombre del Estado', 'Descripción del Estado');
