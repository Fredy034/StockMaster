INSERT INTO "Producto" ("IdTipoProducto", "Nombre", "Descripcion", "Precio", "Stock")
VALUES ('id-tipo-producto', 'Nombre del Producto', 'Descripción del Producto', 100.00, 50);
