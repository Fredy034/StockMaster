SELECT "IdFactura", "IdEstadoFactura", "IdMetodoPago", "IdEmpleado", "IdCliente", "NumeroFactura", "Fecha", "Total", "Notas", "Activo", "Actualiza"
FROM "Factura"
WHERE "IdFactura" = 'a2d14be8-a1bd-4664-8f4b-b896efe3a04b'
  AND "Activo" = b'1';
