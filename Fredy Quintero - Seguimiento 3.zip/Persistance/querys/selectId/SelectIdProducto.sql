SELECT "IdProducto", "IdTipoProducto", "Nombre", "Descripcion", "Precio", "Stock", "Activo", "Actualiza"
FROM "Producto"
WHERE "IdProducto" = 'a2d14be8-a1bd-4664-8f4b-b896efe3a04b'
  AND "Activo" = b'1';
