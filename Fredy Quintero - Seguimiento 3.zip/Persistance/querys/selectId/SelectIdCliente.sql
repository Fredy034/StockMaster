SELECT "IdCliente", "IdPersona", "FechaRegistro", "Direccion", "Activo", "Actualiza"
FROM "Cliente"
WHERE "IdCliente" = 'a2d14be8-a1bd-4664-8f4b-b896efe3a04b'
  AND "Activo" = b'1';
