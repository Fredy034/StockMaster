INSERT INTO "DetalleFactura" ("IdFactura", "IdProducto", "Cantidad", "Subtotal")
VALUES 
('14ace730-3ebc-4191-b33d-d20a454d5016', 'b3f1fbca-1496-4b98-a393-edd3a394a45a', 2, 50.00),
('2a14ff23-4c5c-41a3-90aa-c6adb9aefc71', '46dcb447-912f-4b16-be88-4d1b84bf9920', 1, 10.00),
('2a14ff23-4c5c-41a3-90aa-c6adb9aefc71', '48b0cbcc-5417-417c-a590-57a2932385d8', 3, 9.00);
