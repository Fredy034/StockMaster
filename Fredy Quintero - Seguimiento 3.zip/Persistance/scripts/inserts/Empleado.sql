INSERT INTO "Empleado" ("IdPersona", "IdSucursal", "FechaContratacion", "Salario")
VALUES 
('ed0d3999-acda-47ec-988b-c57f6377f0c3', '238d2e0b-780a-4845-a4a1-ec8d7675732c', '2024-01-01', 2500.00),
('ab953656-a3f2-455c-92a8-0004fc533ee3', '1906cd88-c1ed-42ff-8761-4efe188128c5', '2024-02-01', 2700.00),
('d41a2c5c-efc8-4bea-9225-dbd84461d445', '3014be28-24fe-4b97-9f37-67b65495ea9c', '2024-03-01', 2600.00);
