INSERT INTO "EstadoFactura" ("Nombre", "Descripcion")
VALUES 
('Pendiente', 'Factura pendiente de pago'),
('Pagada', 'Factura ya pagada'),
('Cancelada', 'Factura cancelada');
