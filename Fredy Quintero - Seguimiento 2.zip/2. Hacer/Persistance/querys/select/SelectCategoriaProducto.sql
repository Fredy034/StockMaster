SELECT "IdCategoriaProducto", "Nombre", "Descripcion", "Activo", "Actualiza"
FROM "CategoriaProducto"
WHERE "Activo" = b'1';
