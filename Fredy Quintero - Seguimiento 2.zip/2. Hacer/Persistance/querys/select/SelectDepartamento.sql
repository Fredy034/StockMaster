SELECT "IdDepartamento", "IdPais", "Nombre", "Activo", "Actualiza"
FROM "Departamento"
WHERE "Activo" = b'1';
