SELECT "IdEmpleado", "IdPersona", "IdSucursal", "FechaContratacion", "Salario", "Activo", "Actualiza"
FROM "Empleado"
WHERE "Activo" = b'1';
