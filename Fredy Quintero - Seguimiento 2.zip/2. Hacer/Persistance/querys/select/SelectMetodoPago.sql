SELECT "IdMetodoPago", "Nombre", "Descripcion", "Activo", "Actualiza"
FROM "MetodoPago"
WHERE "Activo" = b'1';
