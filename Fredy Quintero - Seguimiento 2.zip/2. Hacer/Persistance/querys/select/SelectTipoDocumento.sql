SELECT "IdTipoDocumento", "Nombre", "Activo", "Actualiza"
FROM "TipoDocumento"
WHERE "Activo" = b'1';
