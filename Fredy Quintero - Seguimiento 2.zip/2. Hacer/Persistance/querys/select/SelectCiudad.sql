SELECT "IdCiudad", "IdDepartamento", "Nombre", "Activo", "Actualiza"
FROM "Ciudad"
WHERE "Activo" = b'1';
