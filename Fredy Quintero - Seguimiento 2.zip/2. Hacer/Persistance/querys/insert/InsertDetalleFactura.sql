INSERT INTO "DetalleFactura" ("IdFactura", "IdProducto", "Cantidad", "Subtotal")
VALUES ('id-factura', 'id-producto', 10, 100.00);
