INSERT INTO "Ciudad" ("IdDepartamento", "Nombre")
VALUES ('id-departamento', 'Nombre de la Ciudad');
