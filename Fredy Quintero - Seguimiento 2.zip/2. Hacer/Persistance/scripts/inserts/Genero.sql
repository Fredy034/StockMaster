INSERT INTO "Genero" ("Nombre")
VALUES 
('Masculino'),
('Femenino'),
('No Binario');
