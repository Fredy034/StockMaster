INSERT INTO "Pais" ("Nombre")
VALUES 
('Colombia'),
('Perú'),
('Chile');
