INSERT INTO "Factura" ("IdEstadoFactura", "IdMetodoPago", "IdEmpleado", "IdCliente", "NumeroFactura", "Fecha", "Total", "Notas")
VALUES 
('d0935693-1e3b-432b-b036-5af22fcc3908', '2a06ee3a-ab3f-4f80-858e-c07347218baf', 'e3b81dc9-36a9-4150-9f72-9f5c5cb5a600', '02678cc1-fbd2-4798-836c-54f7c74f3d1c', 'F0001', '2024-08-01 10:00:00', 400.00, 'Factura para la compra de productos electrónicos'),
('ca99dff2-3963-419e-8f30-0199f3fbbd80', '00b512d1-5023-4295-a1d6-56220357415d', '745c40ce-1d41-49fa-9779-4150f7e83c2d', '7342fce4-0161-400b-b23b-6db1d0d7ac51', 'F0002', '2024-08-02 11:00:00', 1200.00, 'Compra de una laptop'),
('d9529479-0ebd-45e1-bd3a-35f16e3f1926', 'bc133479-7b3c-4dab-be11-34267a927c69', '4500e57f-06a2-44ea-ab86-a4263daab06b', '7d74b6f6-dc5e-4976-8252-cccaed902721', 'F0003', '2024-08-03 12:00:00', 90.00, 'Compra de camisas');
