INSERT INTO "Cliente" ("IdPersona", "FechaRegistro", "Direccion")
VALUES 
('8ed10e30-6257-42c7-b9ae-bf430cdb5cdc', '2024-01-01', 'Carrera 10 # 20-30'),
('52ddf0ca-f3e2-40e5-93dd-9ba3def823b6', '2024-02-15', 'Avenida 15 # 25-40'),
('ac0cd2d7-d33d-4176-86c6-74fdcd072ecc', '2024-03-22', 'Calle 30 # 10-50');
