INSERT INTO "Sucursal" ("IdCiudad", "IdTienda", "Nombre")
VALUES 
('f456d83e-0413-4446-b619-a12f9358202c', 'bb87d792-493b-428f-95e4-f67ef5cb1f1f', 'Sucursal Medellín Abarrotes'),
('1e90a008-93b8-46fc-8404-04200ed45914', '7eca2826-631e-4cf8-9499-7f2cd645c70c', 'Sucursal Bogotá Abarrotes'),
('27d8f635-7e2e-453d-80b2-c1cb53c5da1b', 'c8330701-3006-435e-9d38-59ffade1cf38', 'Sucursal Cali Abarrotes');
