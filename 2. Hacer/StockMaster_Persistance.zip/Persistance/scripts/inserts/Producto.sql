INSERT INTO "Producto" ("IdTipoProducto", "Nombre", "Descripcion", "Precio", "Stock")
VALUES 
('bf1ce38e-160c-40d7-8a0b-47ba76694e29', 'Arroz Extra', 'Paquete de arroz extra largo', 25.00, 100),
('19385729-588b-4fd4-bbb5-f3992146645b', 'Aceite Vegetal', 'Botella de aceite vegetal de 1 litro', 10.00, 50),
('df83de77-3e51-466e-ba07-7d52d78bdf6e', 'Leche Entera', 'Litro de leche entera', 2.50, 200),
('cc4406f4-7394-464f-9443-7b969415a9af', 'Pan de Molde Integral', 'Paquete de pan de molde integral', 3.00, 80);
