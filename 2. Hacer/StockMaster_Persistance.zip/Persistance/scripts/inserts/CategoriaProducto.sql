INSERT INTO "CategoriaProducto" ("Nombre", "Descripcion")
VALUES 
('Abarrotes', 'Productos de abarrotes y despensa'),
('Lácteos', 'Productos lácteos y derivados'),
('Panadería', 'Productos de panadería y repostería');
