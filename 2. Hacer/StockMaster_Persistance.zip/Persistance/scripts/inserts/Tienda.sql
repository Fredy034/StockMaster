INSERT INTO "Tienda" ("Nombre", "Nit", "Telefono", "Correo")
VALUES 
('Tienda Central', '900123456', '3001234567', 'contacto@tiendacentral.com'),
('Tienda Norte', '900654321', '3007654321', 'contacto@tiendanorte.com'),
('Tienda Sur', '900987654', '3009876543', 'contacto@tiendasur.com');
