INSERT INTO "MetodoPago" ("Nombre", "Descripcion")
VALUES ('Nombre del Método de Pago', 'Descripción del Método de Pago');
