INSERT INTO "Persona" ("IdGenero", "IdTipoDocumento", "IdCiudad", "NombreCompleto", "NumeroDocumento", "Correo", "Telefono", "FechaNacimiento", "Usuario", "Contrasena")
VALUES ('id-genero', 'id-tipo-documento', 'id-ciudad', 'Nombre Completo', 'Número Documento', 'correo@example.com', '1234567890', '1990-01-01', 'usuario', 'contraseña');
