INSERT INTO "Genero" ("Nombre")
VALUES ('Nombre del Género');
