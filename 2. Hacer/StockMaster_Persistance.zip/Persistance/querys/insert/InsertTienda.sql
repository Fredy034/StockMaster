INSERT INTO "Tienda" ("Nombre", "Nit", "Telefono", "Correo")
VALUES ('Nombre de la Tienda', 'Nit de la Tienda', 'Telefono de la Tienda', 'Correo de la Tienda');
