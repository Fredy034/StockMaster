INSERT INTO "Departamento" ("IdPais", "Nombre")
VALUES ('id-pais', 'Nombre del Departamento');
