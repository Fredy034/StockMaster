SELECT "IdTienda", "Nombre", "Nit", "Telefono", "Correo", "Activo", "Actualiza"
FROM "Tienda"
WHERE "Activo" = b'1';
