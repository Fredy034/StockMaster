SELECT "IdGenero", "Nombre", "Activo", "Actualiza"
FROM "Genero"
WHERE "Activo" = b'1';
