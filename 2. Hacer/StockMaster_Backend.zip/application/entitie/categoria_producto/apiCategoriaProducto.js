const express = require('express');
const router = express.Router();

const {
  ModelCategoriaProducto,
  modelcategoriaproducto,
} = require('../../../domain/entitie/categoria_producto/modelCategoriaProducto');

// GET all categoria producto
/**
 * @swagger
 * /getcategoryproduct:
 * get:
 *  summary: Get all category for products
 *  tags: [CategoriaProducto]
 *  responses:
 *    200:
 *      description: Get all category products
 */

router.get('/getcategoryproduct', (req, res) => {
  // res.json(modelcategoriaproducto);
  res.status(200).json(['Esto', 'Es', 'Una', 'Prueba', 'De', 'Categoria', 'Producto']);
});

// POST a new category product
/**
 * @swagger
 * /addcategoryproduct:
 * post:
 *  summary: Add a new category product
 *  requestBody:
 *    required: true
 *    content:
 *      application/json:
 *        schema:
 *          $ref: '#/components/schemas/ModelCategoriaProducto'
 *  tags: [CategoriaProducto]
 *  responses:
 *    201:
 *      description: Category product added
 *    400:
 *      description: Bad request, missing required fields
 */

/*
PAYLOAD EXAMPLE:
{
    "idcategoriaproducto": "1",
    "nombre": "1",
    "descripcion": "1",
    "activo": "1",
    "actualiza": "1"
}
*/

router.post('/addcategoryproduct', (req, res) => {
  const { idcategoriaproducto, nombre, descripcion, activo, actualiza } = req.body;

  if (!idcategoriaproducto || !nombre || !descripcion || !activo || !actualiza) {
    return res.status(400).json({ msg: 'Faltan campos por llenar, completa los campos requeridos' });
  }

  const newModelCategoriaProducto = new ModelCategoriaProducto(idcategoriaproducto, nombre, descripcion, activo, actualiza);

  modelcategoriaproducto.push(newModelCategoriaProducto);
  res.status(201).json({ msg: 'Categoria de producto agregada', product: newModelCategoriaProducto });
  // res.json(newModelCategoriaProducto);
});

module.exports = router;