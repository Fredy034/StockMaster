const express = require('express');
const router = express.Router();

const {
  ModelTipoProducto,
  modeltipoproducto,
} = require('../../../domain/entitie/categoria_producto/modelCategoriaProducto');

// GET all tipo producto
/**
 * @swagger
 * /gettypeproduct:
 * get:
 *  summary: Get all type for products
 *  tags: [TipoProducto]
 *  responses:
 *    200:
 *      description: Get all type products
 */

router.get('/gettypeproduct', (req, res) => {
  // res.json(modeltipoproducto);
  res.status(200).json(['Esto', 'Es', 'Una', 'Prueba', 'De', 'Tipo', 'Producto']);
});

// POST a new type product
/**
 * @swagger
 * /addtypeproduct:
 * post:
 *  summary: Add a new type product
 *  requestBody:
 *    required: true
 *    content:
 *      application/json:
 *        schema:
 *          $ref: '#/components/schemas/ModelTipoProducto'
 *  tags: [TipoProducto]
 *  responses:
 *    201:
 *      description: Type product added
 *    400:
 *      description: Bad request, missing required fields
 */

/*
PAYLOAD EXAMPLE:
{
    "idtipoproducto": "1",
    "idcategoriaproducto": "1",
    "nombre": "1",
    "activo": "1",
    "actualiza": "1"
}
*/

router.post('/addtypeproduct', (req, res) => {
  const { idtipoproducto, idcategoriaproducto, nombre, activo, actualiza } = req.body;

  if (!idtipoproducto || !idcategoriaproducto || !nombre || !activo || !actualiza) {
    return res.status(400).json({ msg: 'Faltan campos requeridos' });
  }

  const newModelTipoProducto = new ModelTipoProducto(idtipoproducto, idcategoriaproducto, nombre, activo, actualiza);

  modeltipoproducto.push(newModelTipoProducto);
  res.status(201).json({ msg: 'Tipo de producto agregado', product: newModelTipoProducto });
  // res.json(newTypeProduct);
});

module.exports = router;
