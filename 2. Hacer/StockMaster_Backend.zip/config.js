import { config } from 'dotenv';
config();

export const PORT = process.env.PORT || 3000;
export const USER = process.env.USER;
export const PASSWORD = process.env.PASSWORD;
export const DBCLUSTER = process.env.DBCLUSTER;
export const DBNAME = process.env.DBNAME;
export const COLLECTION = process.env.COLLECTION;
export const DBID = process.env.DBID;

export const MONGO_URI = `mongodb+srv://${USER}:${PASSWORD}@${DBCLUSTER}.${DBID}.mongodb.net/`;
