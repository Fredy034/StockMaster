const modelcategoriaproducto = [];

class ModelCategoriaProducto {
  constructor(idcategoriaproducto, nombre, descripcion, activo, actualiza) {
    this.idcategoriaproducto = idcategoriaproducto;
    this.nombre = nombre;
    this.descripcion = descripcion;
    this.activo = activo;
    this.actualiza = actualiza;
  }
}

module.exports = { ModelCategoriaProducto, modelcategoriaproducto };
