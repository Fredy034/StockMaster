const modelproductoentity = [];

class ModelProductoEntity {
  constructor(idproducto, idtipoproducto, nombre, descripcion, precio, stock, activo, actualiza) {
    this.idproducto = idproducto;
    this.idtipoproducto = idtipoproducto;
    this.nombre = nombre;
    this.descripcion = descripcion;
    this.precio = precio;
    this.stock = stock;
    this.activo = activo;
    this.actualiza = actualiza;
  }
}

module.exports = { ModelProductoEntity, modelproductoentity };
