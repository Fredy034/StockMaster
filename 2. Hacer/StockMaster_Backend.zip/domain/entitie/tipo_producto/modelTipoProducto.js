const modeltipoproducto = [];

class ModelTipoProducto {
  constructor(idtipoproducto, idcategoriaproducto, nombre, activo, actualiza) {
    this.idtipoproducto = idtipoproducto;
    this.idcategoriaproducto = idcategoriaproducto;
    this.nombre = nombre;
    this.activo = activo;
    this.actualiza = actualiza;
  }
}

module.exports = { ModelTipoProducto, modeltipoproducto };
